#include "DisplayElement.hpp"

BEGIN_CS_NAMESPACE

DoublyLinkedList<DisplayElement> DisplayElement::elements;

END_CS_NAMESPACE