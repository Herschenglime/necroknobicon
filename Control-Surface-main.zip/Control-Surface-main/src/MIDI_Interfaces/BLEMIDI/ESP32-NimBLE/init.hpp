#pragma once

namespace cs::midi_ble_nimble {

bool init_hardware();

}

#include "init.ipp"
