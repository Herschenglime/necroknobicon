// Fill in your WiFi credentials and rename this file to "WiFi-Credentials.h".

const char *ssid = "Your WiFi SSID";
const char *password = "Your WiFi Password";